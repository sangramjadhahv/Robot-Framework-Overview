import time
import re
import logging


from builtins import property
from robot.libraries.BuiltIn import BuiltIn
from robot.utils import timestr_to_secs
from selenium.common.exceptions import (
    StaleElementReferenceException,
    NoSuchElementException,
)
from _datetime import date, datetime, timedelta
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from SeleniumLibrary.errors import ElementNotFound, NoOpenBrowser
from appium.webdriver import webelement
from SeleniumLibrary.keywords import element
from telnetlib import SE

# This script waits for a) Aura to be available and b)
# any in-flight Aura XHRs to be complete.
# We only do this if the page uses Aura, as determined by looking for
# id="auraAppcacheProgress" in the DOM.

WAIT_FOR_AURA_SCRIPT = """
done = arguments[0];
if (document.getElementById('auraAppcacheProgress')) {
    var waitForXHRs = function() {
        if (window.$A && !window.$A.clientService.inFlightXHRs()) {
            done();
        } else {
            setTimeout(waitForXHRs, 100);
        }
    }
    setTimeout(waitForXHRs, 0);
} else {
    done();
}
"""

class SeleniumCommon(object):
    ROBOT_LIBRARY_SCOPE = "GLOBAL"
    
    """Locators"""
    app_name_loc = "//div[contains(@class,'navLeft')]//*[contains(@class,'appName')]/span[text()='{}']"
    object_button_loc = "css: ul.forceActionsContainer.oneActionsRibbon a[title='{}']"
    inlinePanel_button_loc = "//div[contains(@class,'inlinePanel')]//div[contains(@class,'inlineFooter')]//button[.//*[text()='{}']]"
    field_value_loc = "//section[contains(@class,'tabs__content active uiTab')]//*[text()='{}']/../following-sibling::*/*[contains(@class,'test-id__field-value')]"
    date_loc = "//fieldset[contains(@class, 'uiInputDateTime')][.//legend[contains(@class, 'inputLabel')][.//span[text()='{}']]]//label[text()='Date']/following-sibling::input"
    time_loc = "//fieldset[contains(@class, 'uiInputDateTime')][.//legend[contains(@class, 'inputLabel')][.//span[text()='{}']]]//label[text()='Time']/following-sibling::input"
    modal_is_open = "css: div.uiModal div.panel.slds-modal"
    object_field_label = "//label[@for!='' and text()='{}']|//label[@for!=''][./span[text()='{}']]"
    object_field_lookup_link = "//*[@role='option'][.//*[@title='{}']]"
    body = "//div[contains(@class, 'slds-template__container')]/*"
    tab_close_button = "//button[contains(@title,'Close')]"
    select_loadingTxt = "//span[text()='Select...']"
    loadingTxt = "//span[@title='Loading...']"
    auraLoading = "//div[@class='auraLoadingBox oneLoadingBox loadingHide']"        
    
    @property
    def builtin(self):
        return BuiltIn()
    
    @property
    def selenium(self):
        """Returns the instance of the imported SeleniumLibrary library"""
        return self.builtin.get_library_instance("SeleniumLibrary")
    
    def click_inline_Panel_button(self, title):
        """Clicks a button in inline panel."""
        locator = self.inlinePanel_button_loc.format(title)
        self.selenium.wait_until_page_contains_element(locator, timeout=30)
        self.selenium.wait_until_element_is_enabled(locator)
        self.jsClick(locator)
        self.wait_until_loading_is_complete()
        
    def jsClick(self, locator):
        """Clicks the locator in a Lightning modal."""        
        self.selenium.wait_until_page_contains_element(locator, timeout=30)
        self.selenium.wait_until_element_is_enabled(locator, timeout=30)
        self._jsclick(locator)    
        
    def custom_click_app_in_applauncher(self, appLocator):
        """Clicks the app in app launcher view all screen"""
        self.selenium.wait_until_element_is_enabled(appLocator, timeout=30)
        self.selenium.set_focus_to_element(appLocator)
        elem = self.selenium.get_webelement(appLocator)
        link = elem.find_element_by_xpath("../../..")
        self.selenium.set_focus_to_element(link)
        link.click()  
    
    def custom_current_app_should_be (self, app_name):        
        locator_app = self.app_name_loc.format(app_name)
        elem = self.selenium.get_webelement(locator_app)        
        assert app_name == elem.text, "Expected app to be {} but found {}".format(
            app_name, elem.text
        )
        
    def custom_click_object_button(self, title):
        """Clicks a button in an object's actions. The cumulusCI keyword expects modal window to open 
            but there are scenarios where normal window is getting open on clicking object button. 
            This keyword is written for such scenarios where modal window is not getting open"""        
        locator = self.object_button_loc.format(title)
        self.selenium.wait_until_page_contains_element(locator, timeout=30)
        self.jsClick(locator)
        self.wait_until_loading_is_complete()
        #self.wait_until_salesforce_is_ready(locator)
    
    def field_value_should_be(self, label, expectedValue):
        """This will compare the actual field value with expected value. This is mainly for the fields under details tab"""
        locator = self.field_value_loc.format(label)
        actualValue = self.selenium.get_text(locator)
        assert actualValue == expectedValue, "Expected value to be '{}' but found '{}'".format(expectedValue, actualValue)
                 
    def set_start_and_end_date_time(self, startLabel, endLabel, duration, timeFormat):
        """Set start and end date time of the give label. Start time will be set as current system time and
            end time will be calculated based on duration. TimeFormat should be 12 or 24 based on the time field"""
        start_date = self.date_loc.format(startLabel)
        start_time = self.time_loc.format(startLabel)
        end_date = self.date_loc.format(endLabel)
        end_time = self.time_loc.format(endLabel)
        start_date_value = date.today().strftime("%d/%m/%Y")
        start_time_value = ""        
        if timeFormat == '24':            
            start_time_value = datetime.now().strftime("%H:%M")
        elif timeFormat == '12':
            start_time_value = datetime.now().strftime("%I:%M %p")
        end_date_time_value = datetime.now() + timedelta(hours=int(duration))
        end_date_value = end_date_time_value.strftime("%d/%m/%Y")
        end_time_value = ""
        if timeFormat == '24':
            end_time_value = end_date_time_value.strftime("%H:%M")
        elif timeFormat == '12':
            end_time_value = end_date_time_value.strftime("%I:%M %p")
        logging.info(start_time_value)
        self.selenium.input_text(start_date, start_date_value)
        #As we are bypassing time dropdown, for some reason input text add 12:00 in the beginning, so to clear it we are calling the same keyword twice
        self.selenium.input_text(start_time, start_time_value)
        self.selenium.input_text(start_time, start_time_value)
        self.selenium.input_text(end_date, end_date_value)
        self.selenium.input_text(end_time, end_time_value)
        self.selenium.input_text(end_time, end_time_value)
        
    def check_for_classic(self):
        """Switch to lightning if we land on a classic page

        This seems to happen randomly, causing tests to fail
        catastrophically. The idea is to detect such a case and
        auto-click the "switch to lightning" link

        """
        try:
            # we don't actually want to wait here, but if we don't
            # explicitly wait, we'll implicitly wait longer than
            # necessary.  This needs to be a quick-ish check.
            self.selenium.wait_until_element_is_visible(
                "class:switch-to-lightning", timeout=2
            )
            self.builtin.log(
                "It appears we are on a classic page; attempting to switch to lightning",
                "WARN",
            )
            # just in case there's a modal present we'll try simulating
            # the escape key. Then, click on the switch-to-lightning link
            self.selenium.press_keys(None, "ESC")
            self.builtin.sleep("1 second")
            self.selenium.click_link("class:switch-to-lightning")
            return True

        except (NoSuchElementException, AssertionError):
            return False       

           
    def _jsclick(self, locator):
        """Use javascript to click an element on the page

        See https://help.salesforce.com/articleView?id=000352057&language=en_US&mode=1&type=1
        """

        self.selenium.wait_until_page_contains_element(locator)
        self.selenium.wait_until_element_is_enabled(locator)
        for should_retry in (True, False):
            try:
                # Setting the focus first seems to be required as of Spring'20
                # (read: without it, tests started failing in that release). I
                # suspect it's because there is a focusOut handler on form
                # fields which need to be triggered for data to be accepted.
                element = self.selenium.get_webelement(locator)
                self.selenium.driver.execute_script(
                    "arguments[0].focus(); arguments[0].click()", element
                )
                return
            except StaleElementReferenceException:
                if should_retry:
                    time.sleep(1)
                else:
                    raise
     
    def populate_field(self, name, value):
        """Enters a value into an input or textarea field.

        'name' represents the label on the page (eg: "First Name"),
        and 'value' is the new value.

        Any existing value will be replaced.
        """
        locator = self._get_input_field_locator(name)
        self.selenium.wait_until_page_contains_element(locator, timeout=30)        
        self._populate_field(locator, value)
        
    def _get_input_field_locator(self, name):
        """Given an input field label, return a locator for the related input field

        This looks for a <label> element with the given text, or
        a label with a span with the given text. The value of the
        'for' attribute is then extracted from the label and used
        to create a new locator with that id.

        For example, the locator 'abc123' will be returned
        for the following html:

        <label for='abc123'>First Name</label>
        -or-
        <label for='abc123'><span>First Name</span>
        """
        try:
            # we need to make sure that if a modal is open, we only find
            # the input element inside the modal. Otherwise it's possible
            # that the xpath could pick the wrong element.
            self.selenium.get_webelement(self.modal_is_open)
            modal_prefix = "//div[contains(@class, 'modal-container')]"
        except ElementNotFound:
            modal_prefix = ""

        locator = modal_prefix + self.object_field_label.format(
            name, name
        )
        input_element_id = self.selenium.get_element_attribute(locator, "for")
        return input_element_id 
    
    def _populate_field(self, locator, value):
        self.builtin.log(f"value: {value}' locator: '{locator}'", "DEBUG")
        field = self.selenium.get_webelement(locator)
        self._focus(field)
        if field.get_attribute("value"):
            self._clear(field)
        actions = ActionChains(self.selenium.driver)
        actions.send_keys_to_element(field, value).perform()  
        
    def _focus(self, element):
        """Set focus to an element

        In addition to merely setting the focus, we click the mouse
        to the field in case there are functions tied to that event.
        """
        actions = ActionChains(self.selenium.driver)
        actions.move_to_element(element).click().perform()
        self.selenium.set_focus_to_element(element)
        
    def _clear(self, element):
        """Clear the field, using any means necessary

        This is surprisingly hard to do with a generic solution. Some
        methods work for some components and/or on some browsers but
        not others. Therefore, several techniques are employed.
        """

        element.clear()
        self.selenium.driver.execute_script("arguments[0].value = '';", element)

        # Select all and delete just in case the element didn't get cleared
        element.send_keys(Keys.HOME + Keys.SHIFT + Keys.END)
        element.send_keys(Keys.BACKSPACE)

        if element.get_attribute("value"):
            # Give the UI a chance to settle down. The sleep appears
            # necessary. Without it, this keyword sometimes fails to work
            # properly. With it, I was able to run 700+ tests without a single
            # failure.
            time.sleep(0.25)

        # Even after all that, some elements refuse to be cleared out.
        # I'm looking at you, currency fields on Firefox.
        if element.get_attribute("value"):
            self._force_clear(element)

    def _force_clear(self, element):
        """Use brute-force to clear an element

        This moves the cursor to the end of the input field and
        then issues a series of backspace keys to delete the data
        in the field.
        """
        value = element.get_attribute("value")
        actions = ActionChains(self.selenium.driver)
        actions.move_to_element(element).click().send_keys(Keys.END)
        for character in value:
            actions.send_keys(Keys.BACKSPACE)
        actions.perform()
        
#     def populate_lookup_field(self, name, value):
#         """Enters a value into a lookup field.
#         """
#         input_locator = self._get_input_field_locator(name)
#         menu_locator = self.object_field_lookup_link.format(value)
#         self.selenium.wait_until_element_is_enabled(input_locator)
#         self._populate_field(input_locator, value)
# 
#         for x in range(5):
#             self.wait_for_aura()
#             try:
#                 self.selenium.get_webelement(menu_locator)
#             except ElementNotFound:
#                 # Give indexing a chance to catch up
#                 time.sleep(2)
#                 field = self.selenium.get_webelement(input_locator)
#                 field.send_keys(Keys.BACK_SPACE)
#             else:
#                 break
#         self.selenium.set_focus_to_element(menu_locator)
#         self.jsClick(menu_locator)
        
    def wait_for_aura(self):
        """Run the WAIT_FOR_AURA_SCRIPT.

        This script polls Aura via $A in Javascript to determine when
        all in-flight XHTTP requests have completed before continuing.
        """
        try:
            self.selenium.driver.execute_async_script(WAIT_FOR_AURA_SCRIPT)
        except Exception:
            pass       
        
    def wait_until_salesforce_is_ready(self, timeout=60, locator=None, interval=10):
        """This one should be used only when we Login or load new URL or refresh page 
        Waits until we are able to render the initial salesforce landing page

        It will continue to refresh the page until we land on a
        lightning page or until a timeout has been reached. The
        timeout can be specified in any time string supported by robot
        (eg: number of seconds, "3 minutes", etc.). If not specified,
        the default selenium timeout will be used.

        This keyword will wait a few seconds between each refresh, as
        well as wait after each refresh for the page to fully render
        (ie: it calls wait_for_aura())

        """

        # Note: we can't just ask selenium to wait for an element,
        # because the org might not be availble due to infrastructure
        # issues (eg: the domain not being propagated). In such a case
        # the element will never come. Instead, what we need to do is
        # repeatedly refresh the page until the org responds.
        #
        # This assumes that any lightning page is a valid stopping
        # point.  If salesforce starts rendering error pages with
        # lightning, or an org's default home page is not a lightning
        # page, we may have to rethink that strategy.
        
        interval = 5  # seconds between each refresh.
        timeout = timeout if timeout else self.selenium.get_selenium_timeout()
        timeout_seconds = timestr_to_secs(timeout)
        start_time = time.time()        
        locator = self.body if locator is None else locator
        selectLocator = self.select_loadingTxt
        loadingLocator = self.loadingTxt
        auraLoadingLocator = self.auraLoading

        while True:
            try:                
                self.selenium.wait_until_page_contains_element(auraLoadingLocator, timeout=30)                                                       
                self.selenium.wait_until_page_contains_element(selectLocator, timeout=30)
                self.selenium.wait_until_location_does_not_contain("one/one.app")
                
                # If the following doesn't throw an error, we're good to go.
                self.selenium.get_webelement(auraLoadingLocator)
                break

            except Exception as e:
                self.builtin.log(
                    "caught exception while waiting: {}".format(str(e)), "DEBUG"
                )
                if time.time() - start_time > timeout_seconds:
                    self.selenium.log_location()
                    raise Exception("Timed out waiting for a lightning page")
                
            
            time.sleep(interval)
            self.selenium.reload_page()      
                
               
        self.selenium.wait_until_page_does_not_contain_element(selectLocator, timeout=20) 
        logging.info("Waiting for Select... to disappear")               
        self.selenium.wait_until_page_does_not_contain_element(loadingLocator, timeout=20, error="loading not found")
        logging.info("Waiting for Loading... to disappear")  
            
                
    def wait_until_loading_is_complete(self, locator=None):
        """Wait for LEX page to load.

        (We're actually waiting for the actions ribbon to appear.)
        """
        locator = self.body if locator is None else locator
        loadingLocator = self.loadingTxt
        
        try:            
            self.selenium.wait_until_page_contains_element(locator, timeout=60)
            self.wait_for_aura()
            self.selenium.wait_until_page_does_not_contain_element(loadingLocator, timeout=60, error="loading not found")
            logging.info("Waiting for Loading... to disappear")             
            # this knowledge article recommends waiting a second. I don't
            # like it, but it seems to help. We should do a wait instead,
            # but I can't figure out what to wait on.
            # https://help.salesforce.com/articleView?id=000352057&language=en_US&mode=1&type=1
            time.sleep(1)

        except Exception:
            try:
                self.selenium.capture_page_screenshot()
            except Exception as e:
                self.builtin.warn("unable to capture screenshot: {}".format(str(e)))
            raise        

        
    def get_field_value(self, label):
        """Return the current value of a form field based on the field label"""
        input_element_id = self.selenium.get_element_attribute(
            "xpath://label[contains(., '{}')]".format(label), "for"
        )
        value = self.selenium.get_value(input_element_id)
        return value
    
    def quitdriver(self):
        self.selenium.driver.quit()