import os.path
import shutil
from datetime import datetime
import pathlib
import string
from pathlib import Path
import string
import errno
from shutil import copy



"""Listener that parses the output XML when it is ready and creates a unique log."""

ROBOT_LISTENER_API_VERSION = 3

def start_suite(name, attributes):
     ##start for tc
     curDir = os.getcwd()
     splitr = curDir.split("\\")
     print("split" + " " + splitr[-1])
     datewithTime = datetime.now().strftime('%H-%M-%S')
     print("time" + datewithTime)
     ##end
     tcdirectory = os.path.abspath('..')
     print("dir0:" + tcdirectory)
     parentDir = os.path.abspath(os.path.join(tcdirectory, os.pardir))
     print("parentdir:" +parentDir)
     if not os.path.exists(parentDir +'\Report'):
         os.makedirs(parentDir +'\Report')
     curdate = datetime.now().strftime('%d-%m-%Y')
     if not os.path.exists(parentDir +'\Report' + '/' + (datetime.now().strftime('%d-%m-%Y'))):
         os.makedirs(parentDir +'\Report' + '/' + (datetime.now().strftime('%d-%m-%Y')))
     if not os.path.exists(parentDir +'\Report' + '/' + (datetime.now().strftime('%d-%m-%Y')) + '/' + splitr[-1] + datewithTime):
         os.makedirs(parentDir +'\Report' + '/' + (datetime.now().strftime('%d-%m-%Y')) + '/' + splitr[-1] + datewithTime)


     # mydir = os.path.join(os.getcwd(),datetime.now().strftime('%Y-%m-%d'))
     # print("currentdir:" + mydir)
    # try:
    #     os.makedirs(mydir)
    # except OSError as e:
    #     if e.errno != errno.EEXIST:
    #         raise  # This was not a "directory exist" error..
    # with open(os.path.join(mydir, filename), 'w') as d:
    #     d.writelines(list)

def start_test(name, attributes):
    splitr = [];
    curDir = os.getcwd()
    splitr = curDir.split("\\")
    print("split" + " " +  splitr[-1])
    datewithTime = datetime.now().strftime('%d-%m-%Y-%H:%M:%S')
    print("time" + datewithTime)



def output_file(path):
    # parse xml with etree or lxml
      log_dir = os.path.split(path)[0]
      print('Extra log: %s' % (log_dir + '\\extra.log'))
      shutil.copy(log_dir + '\\output.xml' , log_dir + '\Report1')

def report_file(path):
     # parse xml with etree or lxml
     log_dir = os.path.split(path)[0]
     print('Extra log: %s' % (log_dir + '\\extra.log'))
     shutil.copy(log_dir + '\\report.html' , log_dir + '\Report1')


def log_file(path):
    # parse xml with etree or lxml
    log_dir = os.path.split(path)[0]
    print('Extra log: %s' % (log_dir + '\\extra.log'))
    shutil.copy(log_dir + '\\log.html', log_dir + '\Report1')
